import { CityValidationDirective } from './city-validation.directive';

describe('CityValidationDirective', () => {
  it('should create an instance', () => {
    const directive = new CityValidationDirective();
    expect(directive).toBeTruthy();
  });
});
